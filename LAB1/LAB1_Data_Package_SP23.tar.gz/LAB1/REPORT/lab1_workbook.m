%A3310 LAB1 WORKBOOK SPRING 2023
%Name: ______
%Date: ______

%include the Matlab commands you used to answer the LAB questions in this
%workbook. If run, the workbook should generate all figure and save all
%images/arrays relevant to the lab without any errors.

%add the LAB1 sub-directories to the Matlab path
addpath(genpath('../'));

%INSERT YOU COMMANDS BELOW (REMEMBER TO COMMENT YOUR CODE!)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%